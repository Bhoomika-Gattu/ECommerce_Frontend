import { Component, EventEmitter, NgModule, Output } from '@angular/core';
import { RouterModule, RouterOutlet } from '@angular/router';
import { ProductListComponent } from './product-list/product-list.component';
import { FormsModule, NgModel } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { CategoryListComponent } from './category-list/category-list.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet,ProductListComponent,RouterModule,FormsModule,CommonModule,CategoryListComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'ecomm_frontend';

  currentProductName: string = '';

  @Output() productSearch: EventEmitter<string> = new EventEmitter<string>();  

 
  onSubmit(): void {
    console.log("app component product name:"+this.currentProductName);
    this.productSearch.emit(this.currentProductName); 
  }
}
